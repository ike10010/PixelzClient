package com.pixelz.client.util;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationUtil {
    public static float[] getRotationsTo(class_1297 entity) {
        var mc = class_310.method_1551();
        if (mc.field_1724 == null) return new float[]{0,0};
        class_243 eyes = mc.field_1724.method_33571();
        class_243 target = entity.method_5829().method_1005();
        // aim at center slightly up
        target = new class_243(target.field_1352, entity.method_5829().method_1005().field_1351 + 0.4, target.field_1350);
        double dx = target.field_1352 - eyes.field_1352;
        double dy = target.field_1351 - eyes.field_1351;
        double dz = target.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx*dx + dz*dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ class_3532.method_15393(yaw), class_3532.method_15363(pitch, -90, 90) };
    }
}
