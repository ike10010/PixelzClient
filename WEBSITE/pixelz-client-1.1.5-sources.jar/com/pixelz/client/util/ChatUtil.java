package com.pixelz.client.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ChatUtil {
    public static void info(String msg) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("§8[§dPixelz§8] §7" + msg), false);
    }
    public static void action(String msg) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("§8[§dPixelz§8] §7" + msg), true);
    }
}
