package com.pixelz.client.gui;

import com.pixelz.client.alt.Alt;
import com.pixelz.client.alt.AltManager;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Wurst-style AltManager GUI - add/edit/remove/star/login alts without restarting.
 * Cracked login works offline; premium shows Prism hint (like Wurst does for Microsoft).
 */
public class AltManagerScreen extends class_437 {
    private final class_437 parent;
    private final AltManager manager = AltManager.getInstance();
    private Alt selected = null;
    private int scroll = 0;
    private String status = "";
    private long statusTime = 0;

    public AltManagerScreen(class_437 parent) {
        super(class_2561.method_43470("AltManager - Wurst Style"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int w = field_22789 / 2;
        int y0 = 42;

        // Buttons - Wurst style bottom row
        method_37063(class_4185.method_46430(class_2561.method_43470("Login"), b -> loginSelected()).method_46434(w - 210, field_22790 - 28, 68, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Add"), b -> openAdd()).method_46434(w - 136, field_22790 - 28, 50, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Edit"), b -> openEdit()).method_46434(w - 80, field_22790 - 28, 50, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Remove"), b -> removeSelected()).method_46434(w + -24, field_22790 - 28, 60, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("★ Star"), b -> starSelected()).method_46434(w + 40, field_22790 - 28, 58, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Prism Hint"), b -> status("For Microsoft alts, use PrismLauncher → Accounts (more secure than password).", true)).method_46434(w + 102, field_22790 - 28, 80, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Back"), b -> method_25419()).method_46434(field_22789 - 60, 12, 50, 20).method_46431());

        // Direct login field
        method_37063(class_4185.method_46430(class_2561.method_43470("Direct Login (name)"), b -> directLogin()).method_46434(10, field_22790 - 28, 130, 20).method_46431());
    }

    private void loginSelected() {
        if (selected == null) { status("Select an alt first.", true); return; }
        if (selected.isCracked()) {
            boolean ok = manager.login(selected);
            if (ok) {
                status("Logged in as " + selected.getName() + " (offline).", false);
            } else status("Failed to login cracked alt.", true);
        } else {
            status("Premium alt '" + selected.getName() + "' needs Microsoft token. Use PrismLauncher → Accounts for Microsoft alts.", true);
        }
    }

    private void directLogin() {
        if (field_22787 == null) return;
        field_22787.method_1507(new DirectLoginScreen(this));
    }

    private void openAdd() {
        if (field_22787 == null) return;
        field_22787.method_1507(new AddAltScreen(this, null));
    }

    private void openEdit() {
        if (selected == null) { status("Select an alt to edit.", true); return; }
        if (field_22787 == null) return;
        field_22787.method_1507(new AddAltScreen(this, selected));
    }

    private void removeSelected() {
        if (selected == null) { status("Select an alt to remove.", true); return; }
        manager.removeAlt(selected);
        selected = null;
        status("Removed alt.", false);
    }

    private void starSelected() {
        if (selected == null) { status("Select an alt to star.", true); return; }
        manager.setStarred(selected, !selected.isStarred());
        status(selected.isStarred() ? "Starred " + selected.getName() : "Unstarred " + selected.getName(), false);
    }

    private void status(String msg, boolean isError) {
        status = (isError ? "§c" : "§a") + msg;
        statusTime = System.currentTimeMillis();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        // Title
        context.method_25300(field_22793, "AltManager - Wurst Style", field_22789/2, 14, 0xFFFFFFFF);
        String current = field_22787 != null && field_22787.method_1548() != null ? "Current: " + field_22787.method_1548().method_1676() : "Current: ?";
        context.method_25300(field_22793, current, field_22789/2, 26, 0xFFAAAAAA);
        if (!status.isEmpty() && System.currentTimeMillis() - statusTime < 4000) {
            context.method_25300(field_22793, status, field_22789/2, 38, 0xFFFFFFFF);
        }

        // Alt list box
        int listX = 10;
        int listY = 52;
        int listW = field_22789 - 20;
        int listH = field_22790 - 92;
        context.method_25294(listX, listY, listX + listW, listY + listH, 0x80000000);
        context.method_25294(listX, listY, listX + listW, listY + 1, 0xFF333333);
        context.method_25294(listX, listY + listH - 1, listX + listW, listY + listH, 0xFF333333);
        context.method_25294(listX, listY, listX + 1, listY + listH, 0xFF333333);
        context.method_25294(listX + listW - 1, listY, listX + listW, listY + listH, 0xFF333333);

        var alts = manager.getAlts();
        if (alts.isEmpty()) {
            context.method_25300(field_22793, "No alts. Click Add to create a cracked alt (e.g., PixelzSteve).", field_22789/2, listY + listH/2, 0xFF777777);
        } else {
            int y = listY + 4 - scroll;
            for (int i = 0; i < alts.size(); i++) {
                Alt alt = alts.get(i);
                int entryY = y + i * 20;
                if (entryY < listY - 20 || entryY > listY + listH) continue;
                boolean isSelected = alt == selected;
                int bg = isSelected ? 0xFF2A2A6E : 0xFF1A1A24;
                context.method_25294(listX + 2, entryY, listX + listW - 2, entryY + 18, bg);
                if (isSelected) context.method_25294(listX + 2, entryY, listX + 4, entryY + 18, 0xFF6D5CFF);
                String name = alt.getDisplayName();
                context.method_51433(field_22793, name, listX + 10, entryY + 5, isSelected ? 0xFFFFFFFF : 0xFFCCCCCC, false);
                String type = alt.isCracked() ? "cracked" : "premium";
                context.method_51433(field_22793, type, listX + listW - 70, entryY + 5, 0xFF777777, false);
            }
        }
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mx = click.comp_4798();
        double my = click.comp_4799();
        int listX = 10;
        int listY = 52;
        int listW = field_22789 - 20;
        int listH = field_22790 - 92;
        if (mx >= listX && mx <= listX + listW && my >= listY && my <= listY + listH) {
            var alts = manager.getAlts();
            int y = listY + 4 - scroll;
            for (int i = 0; i < alts.size(); i++) {
                int entryY = y + i * 20;
                if (my >= entryY && my <= entryY + 18) {
                    selected = alts.get(i);
                    if (doubled) loginSelected();
                    return true;
                }
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        var alts = manager.getAlts();
        int maxScroll = Math.max(0, alts.size() * 20 + 8 - (field_22790 - 92));
        scroll = (int) Math.max(0, Math.min(maxScroll, scroll - verticalAmount * 10));
        return true;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == 256) { method_25419(); return true; }
        return super.method_25404(input);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    // --- Add/Edit dialog ---
    private static class AddAltScreen extends class_437 {
        private final class_437 parent;
        private final Alt editTarget;
        private class_342 nameField;
        private class_342 emailField;
        private boolean cracked = true;

        protected AddAltScreen(class_437 parent, Alt editTarget) {
            super(class_2561.method_43470(editTarget == null ? "Add Alt" : "Edit Alt"));
            this.parent = parent;
            this.editTarget = editTarget;
            if (editTarget != null) cracked = editTarget.isCracked();
        }

        @Override
        protected void method_25426() {
            nameField = new class_342(field_22793, field_22789/2 - 100, field_22790/2 - 46, 200, 20, class_2561.method_43470("Name"));
            nameField.method_1880(16);
            nameField.method_47404(class_2561.method_43470("Username (e.g., PixelzSteve)"));
            if (editTarget != null) nameField.method_1852(editTarget.getName());
            method_37063(nameField);
            method_48265(nameField);

            emailField = new class_342(field_22793, field_22789/2 - 100, field_22790/2 - 18, 200, 20, class_2561.method_43470("Email"));
            emailField.method_1880(64);
            emailField.method_47404(class_2561.method_43470("Email (for premium, optional)"));
            if (editTarget != null) emailField.method_1852(editTarget.getEmail());
            method_37063(emailField);

            method_37063(class_4185.method_46430(class_2561.method_43470(cracked ? "Mode: Cracked" : "Mode: Premium"), b -> {
                cracked = !cracked;
                b.method_25355(class_2561.method_43470(cracked ? "Mode: Cracked" : "Mode: Premium"));
            }).method_46434(field_22789/2 - 100, field_22790/2 + 12, 200, 20).method_46431());

            method_37063(class_4185.method_46430(class_2561.method_43470(editTarget == null ? "Add" : "Save"), b -> save()).method_46434(field_22789/2 - 102, field_22790/2 + 40, 96, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419()).method_46434(field_22789/2 + 6, field_22790/2 + 40, 96, 20).method_46431());
        }

        private void save() {
            String name = nameField.method_1882().trim();
            if (name.isEmpty() || name.length() < 3) return;
            String email = emailField.method_1882().trim();
            AltManager mgr = AltManager.getInstance();
            if (editTarget != null) {
                editTarget.setName(name);
                editTarget.setEmail(email);
                editTarget.setCracked(cracked);
                mgr.save();
            } else {
                Alt alt = cracked ? Alt.cracked(name) : Alt.premium(name, email, "");
                mgr.addAlt(alt);
            }
            method_25419();
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            method_25420(context, mouseX, mouseY, delta);
            context.method_25300(field_22793, editTarget == null ? "Add Alt - Wurst Style" : "Edit Alt", field_22789/2, field_22790/2 - 68, 0xFFFFFFFF);
            context.method_51433(field_22793, "Cracked = offline (no password). Premium needs Prism for Microsoft.", field_22789/2 - 100, field_22790/2 + 32, 0xFF777777, false);
            super.method_25394(context, mouseX, mouseY, delta);
        }

        @Override
        public void method_25419() {
            if (field_22787 != null) field_22787.method_1507(parent);
        }

        @Override
        public boolean method_25404(class_11908 input) {
            if (input.comp_4795() == 256) { method_25419(); return true; }
            return super.method_25404(input);
        }
    }

    private static class DirectLoginScreen extends class_437 {
        private final class_437 parent;
        private class_342 nameField;
        protected DirectLoginScreen(class_437 parent) { super(class_2561.method_43470("Direct Login")); this.parent = parent; }
        @Override
        protected void method_25426() {
            nameField = new class_342(field_22793, field_22789/2 - 100, field_22790/2 - 10, 200, 20, class_2561.method_43470("Name"));
            nameField.method_47404(class_2561.method_43470("Username to login (cracked)"));
            method_37063(nameField);
            method_48265(nameField);
            method_37063(class_4185.method_46430(class_2561.method_43470("Login"), b -> {
                String n = nameField.method_1882().trim();
                if (n.length() >= 3) {
                    Alt tmp = Alt.cracked(n);
                    boolean ok = AltManager.getInstance().login(tmp);
                    if (field_22787 != null) field_22787.method_1507(parent);
                }
            }).method_46434(field_22789/2 - 102, field_22790/2 + 16, 96, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419()).method_46434(field_22789/2 + 6, field_22790/2 + 16, 96, 20).method_46431());
        }
        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            method_25420(context, mouseX, mouseY, delta);
            context.method_25300(field_22793, "Direct Login (Cracked)", field_22789/2, field_22790/2 - 32, 0xFFFFFFFF);
            super.method_25394(context, mouseX, mouseY, delta);
        }
        @Override
        public void method_25419() { if (field_22787 != null) field_22787.method_1507(parent); }
        @Override
        public boolean method_25404(class_11908 input) { if (input.comp_4795()==256) {method_25419(); return true;} return super.method_25404(input); }
    }
}
