package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1309;

/**
 * Combat - TriggerBot: attacks the moment crosshair is over entity.
 */
public class TriggerBotModule extends Module {
    public int delay = 50;
    private long last = 0;

    public TriggerBotModule() {
        super("TriggerBot", "TriggerBot - hits when crosshair over entity", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1692 == null || !(mc.field_1692 instanceof class_1309 le) || !le.method_5805()) return;
        if (mc.field_1724.method_5739(mc.field_1692) > 4.5f) return;
        long now = System.currentTimeMillis();
        if (now - last < delay) return;
        if (mc.field_1724.method_7261(0) < 0.9f) return;
        mc.field_1761.method_2918(mc.field_1724, mc.field_1692);
        mc.field_1724.method_6104(class_1268.field_5808);
        last = now;
    }
}
