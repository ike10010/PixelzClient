package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

/**
 * Wurst Render/X-Ray - see ores through walls. Best Wurst visual hack.
 */
public class XRayModule extends Module {
    public boolean fullbright = true;
    public int opacity = 120;

    public XRayModule() {
        super("XRay", "Wurst X-Ray - see ores through blocks", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1769 != null) mc.field_1769.method_3279();
        if (fullbright && mc.field_1690 != null) mc.field_1690.method_42473().method_41748(16.0);
    }

    @Override
    protected void onDisable() {
        if (mc.field_1769 != null) mc.field_1769.method_3279();
    }
}
