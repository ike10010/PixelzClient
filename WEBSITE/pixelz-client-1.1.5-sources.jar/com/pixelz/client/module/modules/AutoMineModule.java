package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * World - AutoMine: automatically mines nearest block.
 */
public class AutoMineModule extends Module {
    public int range = 5;

    public AutoMineModule() {
        super("AutoMine", "AutoMine - mines nearest block", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        class_2338 origin = mc.field_1724.method_24515();
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2338 pos : class_2338.method_25996(origin, range, range, range)) {
            class_2680 state = mc.field_1687.method_8320(pos);
            if (state.method_26215()) continue;
            double d = mc.field_1724.method_5649(pos.method_10263()+0.5, pos.method_10264()+0.5, pos.method_10260()+0.5);
            if (d < bestDist) { bestDist = d; best = new class_2338(pos); }
        }
        if (best == null) return;
        mc.field_1761.method_2910(best, net.minecraft.class_2350.field_11036);
        mc.field_1724.method_6104(class_1268.field_5808);
    }
}
