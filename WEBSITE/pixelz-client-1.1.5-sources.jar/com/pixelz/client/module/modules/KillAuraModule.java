package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import com.pixelz.client.util.RotationUtil;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class KillAuraModule extends Module {
    public float range = 4.2f;
    public int aps = 12; // attacks per second
    public boolean rotate = true;
    public boolean onlyPlayers = false;
    private long lastAttack = 0;

    public KillAuraModule() {
        super("KillAura", "Automatically attacks nearby entities", Category.COMBAT, GLFW.GLFW_KEY_R);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (mc.field_1724.method_29504()) return;

        class_1297 target = findTarget();
        if (target == null) return;

        if (rotate && target instanceof class_1309 le) {
            float[] rots = RotationUtil.getRotationsTo(le);
            mc.field_1724.method_36456(rots[0]);
            mc.field_1724.method_36457(rots[1]);
        }

        long now = System.currentTimeMillis();
        long delay = 1000 / aps;
        if (now - lastAttack < delay) return;
        if (mc.field_1724.method_7261(0) < 0.9f) return;

        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
        lastAttack = now;
    }

    private class_1297 findTarget() {
        class_243 eyes = mc.field_1724.method_33571();
        class_238 search = new class_238(eyes.field_1352 - range, eyes.field_1351 - range, eyes.field_1350 - range, eyes.field_1352 + range, eyes.field_1351 + range, eyes.field_1350 + range);
        return mc.field_1687.method_8333(mc.field_1724, search, e -> {
            if (!(e instanceof class_1309 le)) return false;
            if (!le.method_5805() || le == mc.field_1724) return false;
            if (le.method_5767()) return false;
            if (onlyPlayers && !(e instanceof class_1657)) return false;
            if (e.method_5739(mc.field_1724) > range) return false;
            // anti-bot: ignore dead, invisible armor stands etc
            return true;
        }).stream().min(Comparator.comparingDouble(e -> e.method_5739(mc.field_1724))).orElse(null);
    }
}
