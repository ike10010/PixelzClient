package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

/**
 * Performance - FastRender (fast math, no fancy rendering).
 */
public class FastRenderModule extends Module {
    public boolean fastMath = true;
    public boolean disableEnchantGlint = false;

    public FastRenderModule() {
        super("FastRender", "Performance FastRender - fast math & no fancy effects", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1690 != null) {
            try { mc.field_1690.method_42453().method_41748(0.0); } catch (Exception ignored) {}
            try { mc.field_1690.method_42454().method_41748(0.0); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onDisable() {
        if (mc.field_1690 != null) {
            try { mc.field_1690.method_42453().method_41748(1.0); } catch (Exception ignored) {}
            try { mc.field_1690.method_42454().method_41748(1.0); } catch (Exception ignored) {}
        }
    }
}
