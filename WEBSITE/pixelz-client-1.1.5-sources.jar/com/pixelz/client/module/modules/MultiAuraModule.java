package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_238;

/**
 * Combat - MultiAura: attacks multiple entities per tick.
 */
public class MultiAuraModule extends Module {
    public float range = 4.5f;
    public int maxTargets = 3;

    public MultiAuraModule() {
        super("MultiAura", "MultiAura - hits multiple entities at once", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        var box = new class_238(mc.field_1724.method_23317()-range, mc.field_1724.method_23318()-range, mc.field_1724.method_23321()-range, mc.field_1724.method_23317()+range, mc.field_1724.method_23318()+range, mc.field_1724.method_23321()+range);
        var entities = mc.field_1687.method_8333(mc.field_1724, box, e -> e instanceof class_1309 le && le.method_5805() && e != mc.field_1724 && mc.field_1724.method_5739(e) < range);
        int count = 0;
        for (var e : entities) {
            if (count++ >= maxTargets) break;
            if (mc.field_1724.method_7261(0) < 0.9f) break;
            mc.field_1761.method_2918(mc.field_1724, e);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }
}
