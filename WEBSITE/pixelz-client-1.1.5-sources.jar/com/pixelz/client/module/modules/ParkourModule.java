package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

/**
 * Wurst Movement/Parkour - auto jumps at block edges.
 */
public class ParkourModule extends Module {
    public ParkourModule() {
        super("Parkour", "Wurst Parkour - auto jump at edges", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_24828() && !mc.field_1724.method_5715() && !mc.field_1690.field_1903.method_1434()) {
            // Check if block ahead is air one down
            var pos = mc.field_1724.method_24515().method_10074();
            if (mc.field_1687.method_8320(pos.method_10087(1)).method_26215() && !mc.field_1687.method_8320(pos).method_26215()) {
                // Edge detected - will only jump if next block is jumpable
            }
            // Simple Wurst-like: if moving and block ahead is 1 up, jump
            if (mc.field_1724.field_6250 > 0 && mc.field_1724.field_5976) {
                mc.field_1724.method_6043();
            }
        }
        // Auto parkour on edge
        if (mc.field_1724.method_24828() && mc.field_1724.field_6250 > 0) {
            var ahead = mc.field_1724.method_24515().method_10093(mc.field_1724.method_5735());
            if (mc.field_1687.method_8320(ahead.method_10074()).method_26215() && !mc.field_1687.method_8320(ahead).method_26215()) {
                // actually should not jump here - simplified to not fall
                return;
            }
            if (mc.field_1687.method_8320(ahead).method_26215() && mc.field_1687.method_8320(ahead.method_10074()).method_26215()) {
                mc.field_1724.method_6043();
            }
        }
    }
}
