package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

public class StepModule extends Module {
    public float height = 1.5f;

    public StepModule() {
        super("Step", "Allows you to step up blocks", Category.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1724 != null) {
            try {
                // 1.21.11 attribute based - fallback to generic
                mc.field_1724.method_5996(net.minecraft.class_5134.field_47761).method_6192(height);
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 != null) {
            try {
                mc.field_1724.method_5996(net.minecraft.class_5134.field_47761).method_6192(0.6);
            } catch (Exception ignored) {}
        }
    }
}
