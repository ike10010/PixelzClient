package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1802;

/**
 * Combat - FastBow: enhances bow shooting speed.
 */
public class FastBowModule extends Module {
    public int pullTicks = 3; // vanilla 20

    public FastBowModule() {
        super("FastBow", "FastBow - fast bow shooting", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1724.method_6030().method_7909() != class_1802.field_8102) return;
        if (mc.field_1724.method_6048() >= pullTicks) {
            mc.field_1761.method_2897(mc.field_1724);
        }
    }
}
