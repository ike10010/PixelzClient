package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

/**
 * Movement - Spider: climbs vertical walls like a spider.
 */
public class SpiderModule extends Module {
    public double climbSpeed = 0.2;

    public SpiderModule() {
        super("Spider", "Spider - climb walls", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.field_5976 && mc.field_1724.field_6250 > 0) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, climbSpeed, mc.field_1724.method_18798().field_1350);
        }
    }
}
