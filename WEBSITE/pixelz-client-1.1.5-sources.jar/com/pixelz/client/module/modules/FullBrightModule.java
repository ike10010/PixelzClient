package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1294;
import org.lwjgl.glfw.GLFW;

public class FullBrightModule extends Module {
    public Mode mode = Mode.GAMMA;

    public enum Mode { GAMMA, POTION }

    private double prevGamma;

    public FullBrightModule() {
        super("FullBright", "Makes everything bright", Category.RENDER, -1);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1690 == null) return;
        if (mode == Mode.GAMMA) {
            prevGamma = mc.field_1690.method_42473().method_41753();
            mc.field_1690.method_42473().method_41748(16.0);
        }
    }

    @Override
    protected void onDisable() {
        if (mode == Mode.GAMMA && mc.field_1690 != null) {
            mc.field_1690.method_42473().method_41748(prevGamma);
        }
        if (mc.field_1724 != null) {
            mc.field_1724.method_6016(class_1294.field_5925);
        }
    }

    @Override
    public void onTick() {
        if (mode == Mode.GAMMA && mc.field_1690 != null) {
            if (mc.field_1690.method_42473().method_41753() < 16.0) mc.field_1690.method_42473().method_41748(16.0);
        } else if (mode == Mode.POTION && mc.field_1724 != null) {
            if (!mc.field_1724.method_6059(class_1294.field_5925)) {
                mc.field_1724.method_6092(new net.minecraft.class_1293(class_1294.field_5925, 10000, 0, false, false, false));
            }
        }
    }
}
