package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1713;
import net.minecraft.class_476;

public class ChestStealerModule extends Module {
    public int delay = 2;
    private int ticks;

    public ChestStealerModule() {
        super("ChestStealer", "Automatically steals items from chests", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (!(mc.field_1755 instanceof class_476 screen)) return;
        if (ticks++ < delay) return;
        ticks = 0;
        var handler = screen.method_17577();
        for (int i = 0; i < handler.field_7761.size() - 36; i++) {
            var stack = handler.method_7611(i).method_7677();
            if (!stack.method_7960()) {
                mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                break;
            }
        }
    }
}
