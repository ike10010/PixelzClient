package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public class ScaffoldModule extends Module {
    public boolean tower = true;
    public boolean safeWalk = true;

    public ScaffoldModule() {
        super("Scaffold", "Automatically places blocks under you", Category.WORLD, GLFW.GLFW_KEY_N);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        class_243 pos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_2338 below = class_2338.method_49638(pos.method_1031(0, -1, 0));
        if (!mc.field_1687.method_8320(below).method_26215()) return;

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() instanceof class_1747) {
                slot = i;
                break;
            }
        }
        if (slot == -1) return;

        int prev = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(slot);

        class_3965 hit = new class_3965(class_243.method_24953(below), class_2350.field_11036, below, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (tower && mc.field_1690.field_1903.method_1434() && mc.field_1724.method_24828()) {
            mc.field_1724.method_6043();
        }

        mc.field_1724.method_31548().method_61496(prev);
    }
}
