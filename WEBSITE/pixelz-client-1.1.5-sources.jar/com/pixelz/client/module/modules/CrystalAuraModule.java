package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import com.pixelz.client.util.RotationUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1511;
import net.minecraft.class_238;

/**
 * Wurst Combat/CrystalAura - automatically detonates crystals near enemies.
 * Top Wurst crystal PvP hack.
 */
public class CrystalAuraModule extends Module {
    public float range = 12f;
    public float breakRange = 4.5f;
    public boolean rotate = true;
    private long lastAttack = 0;

    public CrystalAuraModule() {
        super("CrystalAura", "Wurst CrystalAura - auto crystal PvP", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        long now = System.currentTimeMillis();
        if (now - lastAttack < 100) return;

        var crystals = mc.field_1687.method_8390(class_1511.class, new class_238(mc.field_1724.method_23317() - breakRange, mc.field_1724.method_23318() - breakRange, mc.field_1724.method_23321() - breakRange, mc.field_1724.method_23317() + breakRange, mc.field_1724.method_23318() + breakRange, mc.field_1724.method_23321() + breakRange), e -> !e.method_31481());
        if (crystals.isEmpty()) return;

        var target = crystals.stream().min((a,b) -> Float.compare(a.method_5739(mc.field_1724), b.method_5739(mc.field_1724))).orElse(null);
        if (target == null) return;

        // Find nearby enemies to confirm damage relevance, but for simplicity just break closest
        if (rotate) {
            float[] rots = RotationUtil.getRotationsTo(target);
            mc.field_1724.method_36456(rots[0]);
            mc.field_1724.method_36457(rots[1]);
        }
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
        lastAttack = now;
    }
}
