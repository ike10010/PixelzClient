package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1799;
import net.minecraft.class_2680;

/**
 * Wurst Blocks/AutoTool - auto switches to best tool when mining.
 */
public class AutoToolModule extends Module {
    public AutoToolModule() {
        super("AutoTool", "Wurst AutoTool - auto best tool", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1765 == null) return;
        if (!(mc.field_1765 instanceof net.minecraft.class_3965 bhr)) return;
        class_2680 state = mc.field_1687.method_8320(bhr.method_17777());
        if (state.method_26215()) return;
        if (!mc.field_1690.field_1886.method_1434()) return;

        int bestSlot = -1;
        float bestSpeed = 1f;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }
        if (bestSlot != -1) mc.field_1724.method_31548().method_61496(bestSlot);
    }
}
