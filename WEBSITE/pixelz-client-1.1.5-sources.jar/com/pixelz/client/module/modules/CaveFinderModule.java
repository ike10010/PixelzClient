package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

/**
 * Wurst Render/CaveFinder - highlights caves and air pockets underground.
 */
public class CaveFinderModule extends Module {
    public int caveOpacity = 80;

    public CaveFinderModule() {
        super("CaveFinder", "Wurst CaveFinder - finds caves and holes", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1769 != null) mc.field_1769.method_3279();
    }

    @Override
    protected void onDisable() {
        if (mc.field_1769 != null) mc.field_1769.method_3279();
    }
}
