package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_2338;

/**
 * Movement - SafeWalk: prevents walking off edges.
 */
public class SafeWalkModule extends Module {
    public SafeWalkModule() {
        super("SafeWalk", "SafeWalk - no walking off edges", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_24828() && !mc.field_1724.method_5715()) {
            class_2338 below = mc.field_1724.method_24515().method_10074();
            class_2338 ahead = mc.field_1724.method_24515().method_10093(mc.field_1724.method_5735());
            // If block ahead is air and below that is air, we are at edge -> sneak
            if (mc.field_1687.method_8320(ahead).method_26215() && mc.field_1687.method_8320(ahead.method_10074()).method_26215()) {
                // Simple safe walk: reduce velocity to 0 at edge
                if (mc.field_1724.method_18798().field_1352 != 0 || mc.field_1724.method_18798().field_1350 != 0) {
                    mc.field_1724.method_18800(0, mc.field_1724.method_18798().field_1351, 0);
                }
            }
        }
    }
}
