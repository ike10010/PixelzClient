package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_238;

/**
 * Combat - ClickAura: attacks only while you click (more legit than KillAura).
 */
public class ClickAuraModule extends Module {
    public float range = 4.2f;

    public ClickAuraModule() {
        super("ClickAura", "ClickAura - attacks while clicking", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (!mc.field_1690.field_1886.method_1434()) return;
        var box = new class_238(mc.field_1724.method_23317()-range, mc.field_1724.method_23318()-range, mc.field_1724.method_23321()-range, mc.field_1724.method_23317()+range, mc.field_1724.method_23318()+range, mc.field_1724.method_23321()+range);
        var target = mc.field_1687.method_8333(mc.field_1724, box, e -> e instanceof class_1309 le && le.method_5805() && e != mc.field_1724 && mc.field_1724.method_5739(e) < range)
            .stream().min((a,b) -> Float.compare(a.method_5739(mc.field_1724), b.method_5739(mc.field_1724))).orElse(null);
        if (target == null) return;
        if (mc.field_1724.method_7261(0) < 0.9f) return;
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
    }
}
