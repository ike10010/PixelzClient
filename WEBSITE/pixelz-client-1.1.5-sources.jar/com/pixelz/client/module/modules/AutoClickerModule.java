package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;

public class AutoClickerModule extends Module {
    public int cps = 10;
    private long last;

    public AutoClickerModule() {
        super("AutoClicker", "Automatically clicks", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (!mc.field_1690.field_1886.method_1434()) return;
        long now = System.currentTimeMillis();
        if (now - last < 1000 / cps) return;
        if (mc.field_1692 != null) {
            mc.field_1761.method_2918(mc.field_1724, mc.field_1692);
            mc.field_1724.method_6104(class_1268.field_5808);
            last = now;
        }
    }
}
