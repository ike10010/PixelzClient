package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_4066;

/**
 * Performance - FPSBoost (Wurst/Sodium-like).
 * Fast graphics, minimal particles, no clouds, reduced shadows.
 */
public class FPSBoostModule extends Module {
    private class_4066 prevParticles;
    private Object prevClouds;
    private Object prevGraphics;

    public FPSBoostModule() {
        super("FPSBoost", "Performance FPSBoost - fast render + minimal particles", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1690 == null) return;
        try {
            prevParticles = mc.field_1690.method_42475().method_41753();
            mc.field_1690.method_42475().method_41748(class_4066.field_18199);
        } catch (Exception ignored) {}
        try {
            mc.field_1690.method_42528().method_41748(net.minecraft.class_4063.field_18162);
        } catch (Exception ignored) {}
        // GraphicsMode FAST not needed - handled via FastRender
        try {
            mc.field_1690.method_42435().method_41748(false);
        } catch (Exception ignored) {}
        if (mc.field_1769 != null) mc.field_1769.method_3279();
        chat("FPSBoost enabled - fast graphics/minimal particles");
    }

    @Override
    protected void onDisable() {
        if (mc.field_1690 == null) return;
        try {
            if (prevParticles != null) mc.field_1690.method_42475().method_41748(prevParticles);
        } catch (Exception ignored) {}
        try {
            mc.field_1690.method_42528().method_41748(net.minecraft.class_4063.field_18164);
        } catch (Exception ignored) {}
        try {
            mc.field_1690.method_42435().method_41748(true);
        } catch (Exception ignored) {}
        if (mc.field_1769 != null) mc.field_1769.method_3279();
    }
}
