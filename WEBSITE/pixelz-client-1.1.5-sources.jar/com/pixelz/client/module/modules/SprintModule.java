package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

public class SprintModule extends Module {
    public boolean keepSprint = true;

    public SprintModule() {
        super("Sprint", "Keeps you sprinting", Category.MOVEMENT);
        setEnabled(true); // enable by default like LB
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_5715() || mc.field_1724.field_5976 || mc.field_1724.method_5799()) return;
        if (mc.field_1724.field_6250 > 0) mc.field_1724.method_5728(true);
    }
}
