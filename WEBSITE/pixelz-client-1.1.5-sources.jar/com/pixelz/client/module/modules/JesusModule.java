package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;

public class JesusModule extends Module {
    public JesusModule() {
        super("Jesus", "Walk on water", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_5799() && !mc.field_1724.method_5715() && !mc.field_1724.method_5681()) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.1, mc.field_1724.method_18798().field_1350);
            mc.field_1724.method_24830(true);
        }
    }
}
