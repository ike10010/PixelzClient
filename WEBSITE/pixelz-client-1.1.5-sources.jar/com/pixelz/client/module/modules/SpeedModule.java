package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import org.lwjgl.glfw.GLFW;

public class SpeedModule extends Module {
    public Mode mode = Mode.STRAFE;
    public double multiplier = 1.6;

    public enum Mode { STRAFE, BHOP, YPORT }

    public SpeedModule() {
        super("Speed", "Makes you faster", Category.MOVEMENT, GLFW.GLFW_KEY_G);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!mc.field_1724.method_24828() && !(mode == Mode.BHOP)) return;
        if (mc.field_1724.method_5715() || mc.field_1724.method_5771() || mc.field_1724.method_5799()) return;

        float yaw = mc.field_1724.method_36454();
        switch (mode) {
            case STRAFE -> {
                if (mc.field_1724.field_6250 == 0 && mc.field_1724.field_6212 == 0) return;
                mc.field_1724.method_18800(
                        Math.cos(Math.toRadians(yaw + 90)) * 0.3 * multiplier,
                        mc.field_1724.method_18798().field_1351,
                        Math.sin(Math.toRadians(yaw + 90)) * 0.3 * multiplier
                );
                if (mc.field_1724.method_24828()) mc.field_1724.method_6043();
            }
            case BHOP -> {
                if (mc.field_1724.method_24828()) {
                    mc.field_1724.method_6043();
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352 * multiplier, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350 * multiplier);
                } else {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352 * 0.99, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350 * 0.99);
                }
            }
            case YPORT -> {
                if (mc.field_1724.method_24828()) {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352 * 1.4, 0.42, mc.field_1724.method_18798().field_1350 * 1.4);
                } else {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -1.0, mc.field_1724.method_18798().field_1350);
                }
            }
        }
    }
}
