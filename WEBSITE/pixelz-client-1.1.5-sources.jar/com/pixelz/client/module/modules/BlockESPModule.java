package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class BlockESPModule extends Module {
    public Set<class_2248> blocks = new HashSet<>(Set.of(class_2246.field_10442, class_2246.field_29029, class_2246.field_22109, class_2246.field_10034, class_2246.field_10443));

    public BlockESPModule() {
        super("BlockESP", "Highlights selected blocks", Category.RENDER);
    }
}
