package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Wurst Blocks/Nuker - destroys blocks around player instantly.
 * Iconic Wurst hack from Blocks category.
 */
public class NukerModule extends Module {
    public int range = 6;
    public boolean onlyLegit = false;
    public boolean autoTool = true;

    public NukerModule() {
        super("Nuker", "Wurst Nuker - breaks blocks around you", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        class_2338 origin = class_2338.method_49637(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        for (class_2338 pos : class_2338.method_25996(origin, range, range, range)) {
            class_2680 state = mc.field_1687.method_8320(pos);
            if (state.method_26215()) continue;
            if (mc.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > range * range) continue;
            if (mc.field_1761.method_2899(pos)) {
                mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
                break;
            }
        }
    }
}
