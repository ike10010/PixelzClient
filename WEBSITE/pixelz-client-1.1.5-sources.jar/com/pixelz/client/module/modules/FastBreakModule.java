package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

/**
 * Wurst Blocks/FastBreak - breaks blocks faster via Haste.
 */
public class FastBreakModule extends Module {
    public int amplifier = 1;

    public FastBreakModule() {
        super("FastBreak", "Wurst FastBreak - faster breaking", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        // Apply Haste II for instant-like break
        mc.field_1724.method_6092(new class_1293(class_1294.field_5917, 10, amplifier, false, false, false));
        // Also set block breaking cooldown to 0 via mixin would be more direct, but haste is packet-safe
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5917);
    }
}
