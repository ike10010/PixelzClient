package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_243;

/**
 * Wurst Render/Freecam - ghost camera with noclip.
 */
public class FreecamModule extends Module {
    private class_243 savedPos;
    private float savedYaw, savedPitch;
    public double speed = 1.0;

    public FreecamModule() {
        super("Freecam", "Wurst Freecam - out-of-body camera", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1724 == null) return;
        savedPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        savedYaw = mc.field_1724.method_36454();
        savedPitch = mc.field_1724.method_36455();
        mc.field_1724.field_5960 = true;
        mc.field_1724.method_31549().field_7479 = true;
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_5960 = false;
        if (!mc.field_1724.method_68878()) mc.field_1724.method_31549().field_7479 = false;
        if (savedPos != null) {
            mc.field_1724.method_23327(savedPos.field_1352, savedPos.field_1351, savedPos.field_1350);
            mc.field_1724.method_36456(savedYaw);
            mc.field_1724.method_36457(savedPitch);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_5960 = true;
        // simple freecam movement is vanilla flying
        float flySpeed = (float)(0.05f * speed);
        mc.field_1724.method_31549().method_7248(flySpeed);
    }
}
