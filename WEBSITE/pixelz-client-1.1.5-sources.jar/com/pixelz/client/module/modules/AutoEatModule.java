package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_9334;

/**
 * Player - AutoEat: consumes food when hunger low.
 */
public class AutoEatModule extends Module {
    public int hungerThreshold = 16;
    public int healthThreshold = 16;

    public AutoEatModule() {
        super("AutoEat", "AutoEat - eats when hungry", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1724.method_7344().method_7586() > hungerThreshold && mc.field_1724.method_6032() > healthThreshold) return;
        if (mc.field_1724.method_6115()) return;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_57826(class_9334.field_50075)) {
                int prev = mc.field_1724.method_31548().method_67532();
                mc.field_1724.method_31548().method_61496(i);
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                // will start using item automatically
                break;
            }
        }
    }
}
