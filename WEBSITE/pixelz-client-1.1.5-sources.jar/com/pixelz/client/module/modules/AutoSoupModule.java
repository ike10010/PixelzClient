package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1802;

/**
 * Player - AutoSoup: drinks mushroom stew when health low.
 */
public class AutoSoupModule extends Module {
    public int healthThreshold = 12;

    public AutoSoupModule() {
        super("AutoSoup", "AutoSoup - heals with stew", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1724.method_6032() > healthThreshold) return;
        if (mc.field_1724.method_6115()) return;
        for (int i = 0; i < 36; i++) {
            var stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8208 || stack.method_7909() == class_1802.field_8515) {
                int slot = i < 9 ? i : i - 9;
                // move to hotbar if needed and use
                if (i >= 9) {
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i, 0, net.minecraft.class_1713.field_7794, mc.field_1724);
                    return;
                }
                mc.field_1724.method_31548().method_61496(slot);
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                break;
            }
        }
    }
}
