package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import com.pixelz.client.util.RotationUtil;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_238;

/**
 * Wurst Combat/BowAimbot - auto-aims bow at nearest entity.
 */
public class BowAimbotModule extends Module {
    public float range = 50f;
    public float fov = 360f;

    public BowAimbotModule() {
        super("BowAimbot", "Wurst BowAimbot - auto aim bow", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!mc.field_1724.method_6115() || mc.field_1724.method_6030().method_7909() != class_1802.field_8102) return;

        var entities = mc.field_1687.method_8333(mc.field_1724, new class_238(mc.field_1724.method_23317()-range, mc.field_1724.method_23318()-range, mc.field_1724.method_23321()-range, mc.field_1724.method_23317()+range, mc.field_1724.method_23318()+range, mc.field_1724.method_23321()+range),
            e -> e instanceof class_1309 le && le.method_5805() && e != mc.field_1724 && mc.field_1724.method_5739(e) < range);
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;
        for (var e : entities) {
            double d = mc.field_1724.method_5739(e);
            if (d < bestDist) { bestDist = d; best = (class_1309)e; }
        }
        if (best == null) return;
        float[] rots = RotationUtil.getRotationsTo(best);
        mc.field_1724.method_36456(rots[0]);
        mc.field_1724.method_36457(rots[1]);
    }
}
