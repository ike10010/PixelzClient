package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * World - VeinMiner: mines entire ore veins automatically.
 */
public class VeinMinerModule extends Module {
    public int range = 6;

    public VeinMinerModule() {
        super("VeinMiner", "VeinMiner - mines ore veins", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (mc.field_1765 == null || !(mc.field_1765 instanceof net.minecraft.class_3965 bhr)) return;
        class_2338 pos = bhr.method_17777();
        class_2680 state = mc.field_1687.method_8320(pos);
        if (state.method_26215()) return;
        class_2248 targetBlock = state.method_26204();
        // Search nearby same block type within range
        for (class_2338 p : class_2338.method_25996(pos, range, range, range)) {
            if (mc.field_1687.method_8320(p).method_26204() == targetBlock) {
                mc.field_1761.method_2910(p, net.minecraft.class_2350.field_11036);
                mc.field_1724.method_6104(class_1268.field_5808);
                break;
            }
        }
    }
}
