package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import com.pixelz.client.util.RotationUtil;
import net.minecraft.class_1309;
import net.minecraft.class_238;

/**
 * Combat - Aimbot / AimAssist: smooth crosshair movement to targets.
 */
public class AimAssistModule extends Module {
    public float range = 6f;
    public float speed = 0.5f;

    public AimAssistModule() {
        super("AimAssist", "Aimbot / AimAssist - smooth aim at targets", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1692 instanceof class_1309) return; // already aiming
        var box = new class_238(mc.field_1724.method_23317()-range, mc.field_1724.method_23318()-range, mc.field_1724.method_23321()-range, mc.field_1724.method_23317()+range, mc.field_1724.method_23318()+range, mc.field_1724.method_23321()+range);
        var entities = mc.field_1687.method_8333(mc.field_1724, box, e -> e instanceof class_1309 le && le.method_5805() && mc.field_1724.method_5739(e) < range);
        class_1309 best = null;
        double closest = Double.MAX_VALUE;
        for (var e : entities) {
            double d = mc.field_1724.method_5739(e);
            if (d < closest) { closest = d; best = (class_1309)e; }
        }
        if (best == null) return;
        float[] rots = RotationUtil.getRotationsTo(best);
        // Smooth aim
        float yaw = mc.field_1724.method_36454() + (rots[0] - mc.field_1724.method_36454()) * speed;
        float pitch = mc.field_1724.method_36455() + (rots[1] - mc.field_1724.method_36455()) * speed;
        mc.field_1724.method_36456(yaw);
        mc.field_1724.method_36457(pitch);
    }
}
