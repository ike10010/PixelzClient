package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1802;

/**
 * Wurst Other/AutoFish - automatically reels and recasts fishing rod.
 * One of Wurst's most popular utility hacks.
 */
public class AutoFishModule extends Module {
    private int tick = 0;
    private boolean wasHooked = false;

    public AutoFishModule() {
        super("AutoFish", "Wurst AutoFish - auto fishing", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1724.method_6047().method_7909() != class_1802.field_8378 && mc.field_1724.method_6079().method_7909() != class_1802.field_8378) return;

        // Simple logic: if bobber is in water and bobs, reel in and recast
        var fishHook = mc.field_1724.field_7513;
        if (fishHook == null) {
            // not fishing, cast
            if (tick++ > 20) {
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                tick = 0;
            }
            wasHooked = false;
            return;
        }

        // Detect catch via fishHook velocity change or when fishHook is biting (onGround false + motion change)
        // Yarn 1.21.11: check if hook is touching water and has caught fish via isTouchingWater + vertical motion
        if (fishHook.method_5799()) {
            double vy = fishHook.method_18798().field_1351;
            // When fish bites, bobber dips: vy < -0.05
            if (vy < -0.05 && !wasHooked) {
                wasHooked = true;
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                tick = 0;
            } else if (vy > -0.01) {
                wasHooked = false;
            }
        }
        tick++;
        if (tick > 600) { // timeout recast every 30s
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            tick = 0;
        }
    }
}
