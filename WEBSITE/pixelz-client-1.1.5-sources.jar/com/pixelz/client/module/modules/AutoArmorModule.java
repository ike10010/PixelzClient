package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_1713;
import net.minecraft.class_1799;

public class AutoArmorModule extends Module {
    private int delay = 0;

    public AutoArmorModule() {
        super("AutoArmor", "Automatically equips best armor", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (delay++ < 5) return;
        delay = 0;
        // Check if any armor slot empty (generic without ArmorItem class)
        boolean hasEmpty = false;
        for (int a = 0; a < 4; a++) {
            // Use generic inventory check via stack emptiness
            try {
                if (mc.field_1724.method_31548().method_5438(36 + a).method_7960()) { hasEmpty = true; break; }
            } catch (Exception e) {
                hasEmpty = true;
                break;
            }
        }
        if (!hasEmpty) return;
        for (int i = 9; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            String name = stack.method_7909().toString().toLowerCase();
            if (name.contains("helmet") || name.contains("chestplate") || name.contains("leggings") || name.contains("boots") || name.contains("armor")) {
                mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                break;
            }
        }
    }
}
