package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_2828;

public class NoFallModule extends Module {
    public NoFallModule() {
        super("NoFall", "Prevents fall damage", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.field_6017 > 3 && mc.field_1724.method_18798().field_1351 < -0.5) {
            if (mc.method_1562() != null) mc.method_1562().method_52787(new class_2828.class_5911(true, mc.field_1724.field_5976));
            mc.field_1724.field_6017 = 0;
        }
    }
}
