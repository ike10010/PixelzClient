package com.pixelz.client.module.modules;

import com.pixelz.client.module.Category;
import com.pixelz.client.module.Module;
import net.minecraft.class_243;
import org.lwjgl.glfw.GLFW;

public class FlyModule extends Module {
    public double speed = 1.0;
    public Mode mode = Mode.VANILLA;

    public enum Mode { VANILLA, CREATIVE }

    public FlyModule() {
        super("Fly", "Allows you to fly", Category.MOVEMENT, GLFW.GLFW_KEY_F);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1724 == null) return;
        chat("Fly enabled - mode: " + mode);
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 == null) return;
        mc.field_1724.method_31549().field_7479 = false;
        mc.field_1724.method_31549().field_7478 = false;
        if (!mc.field_1724.method_68878()) {
            // reset velocity
            class_243 v = mc.field_1724.method_18798();
            mc.field_1724.method_18800(v.field_1352, Math.min(v.field_1351, 0), v.field_1350);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        switch (mode) {
            case VANILLA -> {
                mc.field_1724.method_31549().field_7478 = true;
                // vanilla fly speed
                float flySpeed = (float)(0.05f * speed);
                mc.field_1724.method_31549().method_7248(flySpeed);
                if (mc.field_1690.field_1903.method_1434()) mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.5 * speed, mc.field_1724.method_18798().field_1350);
                if (mc.field_1690.field_1832.method_1434()) mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -0.5 * speed, mc.field_1724.method_18798().field_1350);
            }
            case CREATIVE -> {
                mc.field_1724.method_31549().field_7479 = true;
                mc.field_1724.method_31549().field_7478 = true;
            }
        }
    }
}
