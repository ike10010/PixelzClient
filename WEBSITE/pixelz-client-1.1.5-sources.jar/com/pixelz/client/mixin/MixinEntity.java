package com.pixelz.client.mixin;

import com.pixelz.client.PixelzClient;
import com.pixelz.client.module.modules.VelocityModule;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class MixinEntity {

    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
    private void onPushAwayFrom(class_1297 entity, CallbackInfo ci) {
        if (PixelzClient.INSTANCE == null) return;
        var mm = PixelzClient.INSTANCE.getModuleManager();
        if (mm == null) return;
        var vel = mm.get(VelocityModule.class);
        if (vel != null && vel.isEnabled() && vel.shouldCancel()) {
            // Only cancel for player
            class_1297 self = (class_1297) (Object) this;
            if (self == PixelzClient.mc().field_1724) ci.cancel();
        }
    }

    // 1.21.11: addVelocity(Vec3d) not (DDD) — fixed descriptor
    @Inject(method = "addVelocity", at = @At("HEAD"), cancellable = true)
    private void onAddVelocity(class_243 velocity, CallbackInfo ci) {
        if (PixelzClient.INSTANCE == null) return;
        var vel = PixelzClient.INSTANCE.getModuleManager().get(VelocityModule.class);
        if (vel != null && vel.isEnabled()) {
            class_1297 self = (class_1297) (Object) this;
            if (self == PixelzClient.mc().field_1724) {
                if (vel.mode == VelocityModule.Mode.CANCEL) {
                    ci.cancel();
                } else if (vel.mode == VelocityModule.Mode.REDUCE) {
                    // scale down incoming velocity and apply manually
                    class_243 scaled = new class_243(velocity.field_1352 * vel.horizontal, velocity.field_1351 * vel.vertical, velocity.field_1350 * vel.horizontal);
                    class_1297 e = (class_1297)(Object)this;
                    e.method_18799(e.method_18798().method_1019(scaled));
                    ci.cancel();
                }
            }
        }
    }
}
