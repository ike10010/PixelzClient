package com.pixelz.client.mixin;

import com.pixelz.client.PixelzClient;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class MixinKeyboard {
    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
        if (PixelzClient.INSTANCE != null && PixelzClient.INSTANCE.getModuleManager() != null) {
            int key = input.comp_4795();
            if (key == -1) return;
            PixelzClient.INSTANCE.getModuleManager().onKey(key, action);
        }
    }
}
