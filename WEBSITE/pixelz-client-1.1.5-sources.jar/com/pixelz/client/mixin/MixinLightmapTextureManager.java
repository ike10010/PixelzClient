package com.pixelz.client.mixin;

import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_765.class)
public class MixinLightmapTextureManager {
    // 1.21.11: LightmapTextureManager.update no longer uses NativeImage.setColor(IIII) - FullBright now handled via gamma in FullBrightModule.
    // Kept as placeholder to avoid injection failure (was InvalidInjectionException on 1.21.11).
}
