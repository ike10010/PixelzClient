package com.pixelz.client.mixin;

import com.pixelz.client.PixelzClient;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinWorldRenderer {

    // 1.21.11 WorldRenderer.render signature changed drastically (11 params, FrameGraph etc)
    // Use generic RETURN inject with only CallbackInfo to stay compatible across versions.
    @Inject(method = "render", at = @At("RETURN"))
    private void afterRender(CallbackInfo ci) {
        if (PixelzClient.INSTANCE == null) return;
        var mm = PixelzClient.INSTANCE.getModuleManager();
        if (mm == null) return;
        float tickDelta = 0f;
        try {
            var mc = PixelzClient.mc();
            if (mc != null && mc.method_61966() != null) {
                tickDelta = mc.method_61966().method_60637(true);
            }
        } catch (Exception ignored) {}
        mm.onWorldRender(tickDelta);
    }
}
