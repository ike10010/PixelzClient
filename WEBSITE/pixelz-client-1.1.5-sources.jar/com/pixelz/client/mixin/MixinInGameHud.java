package com.pixelz.client.mixin;

import com.pixelz.client.PixelzClient;
import com.pixelz.client.module.modules.HudModule;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class MixinInGameHud {

    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (PixelzClient.INSTANCE == null) return;
        var mm = PixelzClient.INSTANCE.getModuleManager();
        if (mm == null) return;
        var hud = mm.get(HudModule.class);
        if (hud == null || !hud.isEnabled()) return;

        var mc = PixelzClient.mc();
        if (mc.field_1724 == null) return;

        int y = 4;
        if (hud.watermark) {
            String text = "Pixelz §7- §f1.21.11 §8| §7" + mc.method_47599() + " fps §8| §7LB-inspired";
            context.method_51433(mc.field_1772, text, 4, y, 0xFFDD55FF, true);
            y += 10;
        }

        if (hud.arrayList) {
            var modules = mm.getModules().stream()
                    .filter(m -> m.isEnabled() && !m.isHidden())
                    .sorted((a, b) -> mc.field_1772.method_1727(b.getName()) - mc.field_1772.method_1727(a.getName()))
                    .toList();
            int x = context.method_51421();
            int curY = 4;
            for (var m : modules) {
                String name = m.getDisplayName();
                int w = mc.field_1772.method_1727(name);
                int bx = x - w - 4;
                // background
                context.method_25294(bx - 2, curY - 1, x - 2, curY + 8, 0x80000000);
                context.method_25294(bx - 2, curY - 1, bx, curY + 8, m.getCategory().getColor());
                context.method_51433(mc.field_1772, name, bx, curY, 0xFFFFFFFF, true);
                curY += 9;
            }
        }
    }
}
